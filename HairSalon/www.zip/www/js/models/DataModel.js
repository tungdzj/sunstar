﻿//User model
function UserModel() {
    this.isLogin = false;
    this.userName = '';
    this.password = '';

    this.Validate = function () {
        if (this.userName == "" || this.password.length < 6) {
            return false;
        }
        return true;
    }
    this.cart = new Cart();
    this.order = function(id){
        if (!this.isLogin) {
            this.login();
        } else {
            utils.ShowPrompt('Nhập số lượng mua', 'Đặt hàng', function (n) {
                store.user.cart.addProduct(id, n)
            },
            function () {
            })
        }
    }
    this.removeOrder = function (index) {
        this.cart.removeProduct(index);
    }
    this.checkLogin = function (name, pass) {
        store.user.userName = name;
        store.user.password = pass;
        client.login(function (data) {
            console.log(data);
            if (data.code == '0') {
                utils.ShowMessage('Đăng nhập thành công', 'Thông báo', function () {
                    store.user.isLogin = true;
                    store.user.cart.user = this.userName;
                    store.user.cart.load();
                    store.category.cart.push(new CategoryModel({ 'id': '0', 'name': 'Giỏ hàng' }));

                });
            } else {
                utils.ShowMessage('Sai thông tin tên người dùng hoặc password', 'Thông báo', function () { });
            }
        })
    }

    this.login = function () {
        utils.ShowLogin(this.checkLogin)
    }

    this.logout = function () {
        utils.ShowConfirm('Đăng xuất?', 'Xác nhận', function () {
            store.user.isLogin = false;
            store.data.cart = new NodeModel();
        },
        function () {
        });
    }

    this.sendOrder = function () {
        var product = store.user.cart.product;
        var arr = [];
        for (var i = 0; i < product.length; i++) {
            if (product[i].quantity > 0) {
                arr.push({ 'id': Number(product[i].id), 'count': Number(product[i].quantity) });
            }
        }
        if (arr.length == 0) {
            utils.ShowMessage('Chưa có mặt hàng nào trong giỏ hàng', 'Thông báo', function () { });
            return;
        }
        client.sendOrder(JSON.stringify(arr), function (data) {
            utils.ShowMessage(data.msg, 'Thông báo', function () { })
            store.user.cart.removeAllProduct();
        })
    }

    this.removeAllOrder = function () {
        this.cart.removeAllProduct();
    }

    this.orderPromotion = function (id, quantity) {
        client.orderPromotion(id, quantity, function (data) {
            setTimeout(function () {
                utils.ShowMessage(data.msg, 'Thông báo', function () { });
            }, 500)
            
        })
    }
}

//Category Model
function CategoryModel(data) {
    this.id = data.id;
    this.name = data.name;
    this.parentId = data.parentId;
    this.image = data.image != null ? data.image : 'images/default.png';
    this.child = [];
}


function ItemModel(data) {
    this.id = data.id;
    this.name = data.name;
    this.image = data.image;
    this.content = data.description;
    this.price = data.price;
    this.parentId = data.categoryId;
    this.discount = data.discount;
    this.child = [];
}
//News Model

function NodeModel(data) {
    //default value
    this.id = 0;
    this.parentId = -1;
    this.child = [];
    this.type = 0;
    this.parent = null;
    this.appendChild = function (item) {
        this.child.push(item);
    }
    if (data == null) {
        return;
    }

    this.parentId = data.parentId;
    this.id = data.id;
    this.quantity = data.quantity;
}

function Cart(user) {
    this.user = user;
    this.product = [];
    this.addProduct = function (productId, quantity) {
        this.product.push({ 'id': productId, 'quantity': quantity });
        var node = new NodeModel({
            'id': productId,
            'parentId': '0',
            'quantity':quantity
        });
        node.type = 1;
        store.data.cart.child.push(node);
        this.save();
    }
    this.removeAllProduct = function () {
        this.product = null;
        store.data.cart.child = [];
        this.save();
    }
    this.removeProduct = function (index) {
        this.product.splice(index, 1);
        store.data.cart.child.splice(index, 1);
        this.save();
    }
    this.load = function () {
        var data = JSON.parse(window.localStorage.getItem(user));
        if (data != null) {
            this.product = data;
            for (var i in data) {
                var node = new NodeModel();
                data[i].parent = store.data.cart;
                node.id = data[i].id;
                node.parentId = 0;
                node.type = 1;
                node.quantity = data[i].quantity;
                store.data.cart.appendChild(node);
            }
        }
    }

    this.save = function () {
        var data = JSON.stringify(this.product);
        for (var i in this.product) {
            this.product[i].parent = null;
        }
        window.localStorage.setItem(user, data);
    }
}