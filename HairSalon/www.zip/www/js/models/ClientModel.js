﻿var client = {
    //host: 'http://sunstar.local.vn/',
    host: 'http://sunstar.neonstudio.us/',
    request: function (func, data) {
        var r = this.host + "restapi/restapi.php/" + func;
        for (var p in data) {
            r += '&' + p + '=' + data[p];
        }
        //r = r.replace(func + '&', func + '?');
        return r;
    },

    sendRequest: function (func, params, callback) {
        console.log(this.request(func, params))
        $.ajax({
            url: this.request(func, params),
            dataType: 'jsonp',
            crossDomain: true,
            //async: false,
            success: function (data, textStatus, jqXHR) {
                callback(data);
            },
            error: function (responseData, textStatus, errorThrown) {
            }
        });
    },

    login: function (callback) {
        this.sendRequest('login',
            {
                'username': store.user.userName,
                'password': store.user.password
            }, callback);
    },

    getCategory:function(callback){
        this.sendRequest('getCategory', {}, callback);
    },

    getItem: function (type, callback) {
        var func = '';
        switch (type) {
            case 'order': func = 'getOrder'; break;
            case 'news': func = 'getNews'; break;
            case 'promotion': func = 'getPromotion'; break;
        }
        this.sendRequest(func, {}, callback);
    },
    getNews: function (id, callback) {
        this.sendRequest('getNewsById', { 'id': id }, callback);
    },

    sendOrder: function (json, callback) {
        this.sendRequest('order',
            {
                'username': store.user.userName,
                'password': store.user.password,
                'json': json
            }, callback);
    },

    orderPromotion: function (id, quantity, callback) {
        this.sendRequest('orderPromotion',
            {
                'username': store.user.userName,
                'password': store.user.password,
                'promotionId': id,
                'quantity': quantity
            }, callback);
    }
}