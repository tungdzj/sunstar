﻿var user = null;

var newsArray = [];

var store = {
    user: new UserModel(),
    root: null,
    parent: null,
    active:null,
    data: { 'order': new NodeModel(), 'news': new NodeModel(), 'promotion': new NodeModel(), 'cart': new NodeModel() },
    category: { 'order': [], 'news': [], 'promotion': [], 'cart': [] },
    item: { 'order': [], 'news': [], 'promotion': [], 'cart':[] },
    //category
    getCategory:function(callback){
        client.getCategory(function (data) {
            store.processCategoryData(data);
            callback();
        });
    },

    processCategoryData: function (data) {
        var tmp = [];
        //order category
        for (var i = 0; i < data.data.orderCategory.length; i++) {
            store.category.order[data.data.orderCategory[i].id] = new CategoryModel(data.data.orderCategory[i]);
            data.data.orderCategory[i].type = 0;
            tmp[data.data.orderCategory[i].id] = new NodeModel(data.data.orderCategory[i]);
        }
        store.findChild(0, tmp, store.data.order);
        //news category
        tmp = [];
        for (var i = 0; i < data.data.newsCategory.length; i++) {
            store.category.news[data.data.newsCategory[i].id] = new CategoryModel(data.data.newsCategory[i]);
            data.data.newsCategory[i].type = 0;
            tmp[data.data.newsCategory[i].id] = new NodeModel(data.data.newsCategory[i]);
        }
        store.findChild(0, tmp, store.data.news);

        //promotion category
        tmp = [];
        for (var i = 0; i < data.data.promotionCategory.length; i++) {
            store.category.promotion[data.data.promotionCategory[i].id] = new CategoryModel(data.data.promotionCategory[i]);
            data.data.promotionCategory[i].type = 0;
            tmp[data.data.promotionCategory[i].id] = new NodeModel(data.data.promotionCategory[i]);
        }
        store.findChild(0, tmp, store.data.promotion);

        //add root category node
        store.category.order[0] = new CategoryModel({ 'id': '0', 'name': 'Đặt hàng', 'image': null, 'type': '0', 'parentId': '-1' });
        store.category.news[0] = new CategoryModel({ 'id': '0', 'name': 'Tin tức', 'image': null, 'type': '0', 'parentId': '-1' });
        store.category.promotion[0] = new CategoryModel({ 'id': '0', 'name': 'Khuyến mại', 'image': null, 'type': '0', 'parentId': '-1' });
    },
    //item
    getOrder: function (callback) {
        client.getItem('order', function (data) {
            store.processItemData('order', data.data);
            store.item.cart = store.item.order;
            callback();
        });
    },

    getNews: function (callback) {
        client.getItem('news', function (data) {
            store.processItemData('news', data.data);
            callback();
        });
    },

    getPromotion: function (callback) {
        client.getItem('promotion', function (data) {
            store.processItemData('promotion', data.data);
            callback();
        });
    },

    processItemData: function (type, data) {

        for (var i = 0; i < data.length; i++) {
            var t = new ItemModel(data[i]);
            store.item[type][data[i].id] = t;
            if (store.category[type][t.parentId] != null) {
                var node = new NodeModel(t);
                node.type = 1;
                store.category[type][t.parentId].child.push(node);
            }
        }
        store.appendItemChild(type, store.data[type]);
    },

    appendItemChild: function (type, ref) {
        for (var i = 0; i < store.category[type][ref.id].child.length; i++) {
            var node = store.category[type][ref.id].child[i];
            node.parent = ref;
            ref.appendChild(node);
        }
        for (var i = 0; i < ref.child.length; i++) {
            if (ref.child[i].type == 0) {
                store.appendItemChild(type, ref.child[i]);
            }
        }
    },

    findChild: function (id, source, des) {
        if (des == null) {
            des = new NodeModel();
        }
        for (var i in source) {
            if (source[i].parentId == id) {
                des.appendChild(source[i]);
                des.child[des.child.length - 1].parent = des;
                store.findChild(i, source, des.child[des.child.length - 1]);
            }
        }
    },

    updateNewsContent: function (data) {
        store.news[data.id].content = data.content;
    },

    readNews: function (id, callback) {
        console.log('read ' + id)
        client.getNews(id, function (data) {
            store.item.news[data.data.id].content = data.data.content;
            callback();
        })
    }
}