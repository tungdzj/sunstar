﻿var utils = {
    ShowLoading: function () {
        $.mobile.loading('show');
    },

    HideLoading: function () {
        $.mobile.loading('hide');
    },
    ChangePage: function (page) {
        this.HideLoading();
        $.mobile.changePage('#' + page);
    },
    ShowMessage: function (message, title, callback) {
        $('.popup_msg .header').html(title);
        $('.popup_msg .content').html(message);
        if (callback) {
            $(".popup_msg .ui-btn").bind('tap', function () {
                $(".popup_msg .ui-btn").unbind();
                $(".popup_msg").popup('close');
                callback();
            });
        }
        $(".popup_msg").popup('open');
    },

    ShowConfirm: function (message, title, callback_ok, callback_cancel) {
        message = '<h2>' + message + '</h2>';
        $('.popup_confirm .header').html(title);
        $('.popup_confirm .content').html(message);
        //ok
        $(".popup_confirm .btn_ok").bind('tap', function () {
            $(".popup_confirm .btn_ok").unbind();
            $(".popup_confirm").popup('close');
            callback_ok();
        });
        //cancel
        $(".popup_confirm .btn_cancel").bind('tap', function () {
            $(".popup_confirm .btn_cancel").unbind();
            $(".popup_confirm").popup('close');
            callback_cancel();
        });
        $(".popup_confirm").popup('open');
    },

    ShowPrompt:function(message, title, callback_ok, callback_cancel){
        message = '<h2>' + message + '</h2>';
        $('.popup_prompt .header').html(title);
        $('.popup_prompt .content').html(message);
        //ok
        $(".popup_prompt .btn_ok").bind('tap', function () {
            $(".popup_prompt .btn_ok").unbind();
            $(".popup_prompt").popup('close');
            callback_ok($('.popup_prompt .txt_input').val());
        });
        //cancel
        $(".popup_prompt .btn_cancel").bind('tap', function () {
            $(".popup_prompt .btn_cancel").unbind();
            $(".popup_prompt").popup('close');
            callback_cancel();
        });
        $(".popup_prompt").popup('open');
    },

    ShowLogin: function (callback_ok) {
        $(".popup_login .btn_ok").bind('tap', function () {
            $(".popup_login .btn_ok").unbind();
            $(".popup_login").popup('close')
            $(".popup_login").popup({
                afterclose: function () {
                    callback_ok($("#userName").val(), $("#password").val());
                    $(".popup_login").popup({
                        afterclose: function () { }
                    })
                }

            });
            
        });
        $(".popup_login").popup('open');
    },

    Show:function(selector){
        $(selector).removeClass('hidden');
    },
    Hide: function (selector) {
        $(selector).addClass('hidden');
    }
}