﻿var layout = {
    docHeight: 0,
    docWidth: 0,
    main_scroll: null,
    size: [],
    InitParams: function () {
        this.docHeight = $(document).height();
        this.docWidth = $(document).width();
        this.size['header'] = 10;
        this.size['footer'] = 10;
    },

    InitElements: function () {
        $(".home_content .listview").css('padding-top', (this.docHeight - (this.docWidth / 100 * 82)) / 4);
        $(".popup_msg").enhanceWithin().popup({
            transition:'slidedown'
        });
        $(".popup_confirm").enhanceWithin().popup({
            transition: 'slidedown'
        });
        $(".popup_prompt").enhanceWithin().popup({
            transition: 'slidedown'
        });
        $(".popup_login").enhanceWithin().popup({
            transition: 'slidedown'
        });
        this.main_scroll = new IScroll('.main', {
            scrollbars: true
        });
    },

    InitLayout: function () {
        switch (store.root) {
            case 'home':
                $(".home_content").removeClass('hidden');
                $(".main_content").removeClass('hidden');
                $(".main").css('background', 'url(background: url("../img/bg_home.png")');
                $(".main").css('bottom', 0 + 'vh');
                break;
            case 'news':
                $(".home_content").addClass('hidden');
                $(".main_content").removeClass('hidden');
                utils.Hide('.listview');
                utils.Show('.contentview');
                $(".main").css('bottom', 0 + 'vh');
                break;
            case 'order':
                $(".main_content").removeClass('hidden');
                $(".home_content").addClass('hidden');
                $('.footer').addClass('hidden');
                $(".main").css('bottom', 0 + 'vh');
                break;
            case 'cart':
                $(".main_content").removeClass('hidden');
                $(".home_content").addClass('hidden');
                $('.footer').removeClass('hidden');
                $(".main").css('bottom', this.size['footer'] + 'vh');
                break;
        }
    },

    RefreshLayout: function () {
        layout.main_scroll.refresh();
    }
}


$(document).on('pagechange', function (event) {
    var page = $.mobile.activePage.attr('id');
    if (layout.main_scroll != null) {
        layout.main_scroll.refresh();
    }
})
