﻿var mainView = {
    currentPage: 'category',
    pageTitle: 'Tin tức',
    Refresh: function () {

        if (store.parent.type == '0') { //category type
            $('.page_title').html(store.category[store.root][store.parent.id].name);
            this.ListView(store.parent.child);
        } else if (store.parent.type == '1') {
            $('.page_title').html(store.item[store.root][store.parent.id].name);
            this.ContentView(store.item[store.root][store.parent.id].content);
        }
    },
    ListView: function (parent) {
        layout.InitLayout();
        utils.Show('.main_content .listview');
        utils.Hide('.main_content .contentview');
        $(".main_content .listview li").each(function () {
            $(this).unbind()
        });
        $('.main_content .listview').empty();
        for (var c in parent) {
            if (parent[c].type == 0) {//category type
                if (store.category[store.root][parent[c].id] == null) {
                    return;
                }
                $(".main_content .listview").append(
                    templates.gen('listitem', {
                        'type': 0,
                        'url': client.host + store.category[store.root][parent[c].id].image,
                        'content': store.category[store.root][parent[c].id].name,
                        'id': c,
                        'icon': 'carat-r'
                    }));
            }
            else if (parent[c].type == 1) {//category type
                if (store.item[store.root][parent[c].id] == null) {
                    continue;
                }
                if (store.root == 'cart') {
                    $(".main_content .listview").append(
                    templates.gen('listitem', {
                        'type': 1,
                        'url': client.host + store.item[store.root][parent[c].id].image,
                        'content': store.item[store.root][parent[c].id].name,
                        'id': c,
                        'icon': 'delete',
                        'quantity':parent[c].quantity
                    }));
                } else {
                    $(".main_content .listview").append(
                    templates.gen('listitem', {
                        'type': 1,
                        'url': client.host + store.item[store.root][parent[c].id].image,
                        'content': store.item[store.root][parent[c].id].name,
                        'id': c,
                        'icon': 'plus'
                    }));
                }
                
            }
        }
        
        layout.RefreshLayout();
        $(".main_content .listview li").each(function () {
            $(this).bind('tap', function () {
                var index = $(this).attr('data-id');
                mainControl.onItemClick(index);
            });
        });
        return 'ok';
    },

    ContentView: function (data) {
        layout.InitLayout();
        $('.main_content .contentview').html(data);
        layout.RefreshLayout();
    }
}