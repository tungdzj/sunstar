﻿$(document).ready(function () {
    $(".home_content li").each(function () {
        $(this).bind('tap', function () {
            var index = $(this).attr('data-menu-index');
            mainControl.onMenuItemClick(Number(index));
        });
    })
    $(".btn-menu-left").bind('tap', function () {
        $("#menu").panel('toggle');
    })
    $(".btn-menu-right").bind('tap', function () {
        $("#menu-r").panel('toggle');
    })
});


var mainControl = {
    
    onBackClick: function () {
        if (store.parent.parentId != '-1') {
            store.parent = store.parent.parent;
        }
        mainView.Refresh()
    },
    onMenuItemClick: function (index) {
        switch (index) {
            case 0:
                this.updateData('news');
                break;
            case 1:
                break;
            case 2:
                this.updateData('order');
                break;
            case 3:
                this.updateData('promotion');
                break;
            case 4:
                if (!store.user.isLogin) {
                    store.user.login();
                } else {
                    this.updateData('cart');
                }
                break;
            case 5:
                store.user.login();
                break;
        }
    },
    updateData: function (root) {
        utils.ChangePage('main_page');
        store.root = root;
        if (store.category[root].length == 0) {
            utils.ShowLoading();
            $('.event').bind('onCategoryLoad',
                function () {
                    store.parent = store.data[root];
                    mainView.Refresh();
                    utils.HideLoading();
                })
        } else {
            store.parent = store.data[root];
            mainView.Refresh()
        }
    },
    onItemClick: function (id) {
        if (store.parent.child[id].type == 1) {
            if (store.root == 'order') {
                if (store.user.isLogin) {
                    store.user.order(store.parent.child[id].id);
                } else {
                    store.user.login();
                }
                
            }
            if (store.root == 'cart') {
                utils.ShowConfirm('Xóa khỏi giỏ hàng?', 'Xác nhận', function () {
                    store.user.removeOrder(id);
                    mainView.Refresh();
                }, function () {
                })
            }
            if (store.root == 'news') {
                if (store.item.news[store.parent.child[id].id].content == null) {
                    store.readNews(store.parent.child[id].id, function () {
                        store.parent = store.parent.child[id];
                        mainView.Refresh();
                    });
                }
            }
            if (store.root == 'promotion') {
                if (store.user.isLogin) {
                    utils.ShowPrompt('Nhập số lượng', 'Đặt hàng', function (text) {
                        store.user.orderPromotion(store.parent.child[id].id, text);
                    })
                } else {
                    store.user.login();
                }
            }
        } else {
            if (store.parent.child[id].length == 0) {
                if (store.root == 'promotion') {
                    ultils.ShowMessage('Chương trình khuyến mại đã hết.\nChúc các Salon may mắn trong các chương trình sau.', 'Thông báo', function () { });
                } else {
                    ultils.ShowMessage('Không có sản phẩm nào trong mục này!', 'Thông báo', function () { });
                }
            } else {
                store.parent = store.parent.child[id];
                mainView.Refresh();
            }
            
            
        }
    },

    onCheckoutClick: function () {
        utils.ShowConfirm('Đặt mua tất cả hàng trong giỏ?', 'Xác nhận', function () {
            store.user.sendOrder();
            mainView.Refresh();
        },
        function () {
        })
        
    },
    onDeleteAllClick: function () {
        utils.ShowConfirm('Xóa tất cả hàng trong giỏ?', 'Xác nhận', function () {
            store.user.removeAllOrder();
            mainView.Refresh();
        },
        function () {
        })
        
    }
}