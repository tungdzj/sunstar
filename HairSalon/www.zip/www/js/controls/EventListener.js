﻿var scroll = [];
var responsive = [];
$(document).ready(function () {
    //init iscroll
    layout.InitParams();
    layout.InitElements();

    utils.ChangePage('category_page');

    store.getCategory(function () {
        $('.event').trigger('onCategoryLoad');
        store.getOrder(function () { })
        store.getNews(function () { })
        store.getPromotion(function () { });
    })
});
document.addEventListener('DOMContentLoaded', function () {
    
});
$(document).on('pagecreate', '.main_page', function () {
    $(document).on('swipeleft swiperight', '.main_page', function (e) {
        if ($('.ui-page-active').jqmData('panel') !== 'open') {
            if (e.type = 'swipeleft') {
                $('.menu').panel('open');
            } else {
                $('.menu').panel('close');
            }
        }
    })
})